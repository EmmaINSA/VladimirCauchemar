public class cordes extends instrument{

}
