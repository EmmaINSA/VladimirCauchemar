public class flute extends vents{
	
}
