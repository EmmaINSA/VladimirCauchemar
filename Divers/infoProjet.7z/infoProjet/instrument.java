public class instrument{
	String nom;
	
	public instrument (String nom){
		this.nom=nom;
		}
}
