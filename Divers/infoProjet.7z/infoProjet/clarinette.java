public class clarinette extends vents {
	
	
}

